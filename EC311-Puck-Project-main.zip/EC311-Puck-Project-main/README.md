# EC311-Puck-Project

Team: Vikram Singh Bhalla, Michael Daniels, Junseo Lee, Prashast Pandey

Demo Video: 

Overview: For our project we created a VGA game using verilog code to make a single-player version of the classic game pong, which we renamed puck. Essentailly the point of the game is to volley the ball between your controllable paddle and the wall for as long as possible. However, the speed of the puck increases as you get more volleys.

How to Run: Upload and program our simulation and contrainsts files onto your FPGA and display the FPGA on your monitor. Next, use the up and down buttons to start moving your paddle and you will see your score displayed in bits on the FPGA.

Overview of code: There are 5 code files: Pixel, Debouncer, VGA Controller, and Pong.
